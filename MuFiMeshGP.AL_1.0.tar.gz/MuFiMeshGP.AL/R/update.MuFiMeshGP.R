#########################
### update.MuFiMeshGP ###
#########################

update.MuFiMeshGP <- function(model, x, t, y, init = NULL, param.estim = TRUE){
  x <- matrix(x, nrow = 1)
  X <- rbind(model$X, x)
  meshT <- c(model$meshT, t)
  Y <- c(model$Y,y)
  regF <- model$regF
  estiP <- model$estiP
  covtype <- model$used_args$covtype
  trendtype <- model$used_args$trendtype
  trend.pol <- model$used_args$trend.pol
  interaction <- model$used_args$interaction
  H.known <- model$used_args$H.known
  param.known <- model$used_args$param.known
  sep.sigmasq <- model$used_args$sep.sigmasq
  param.lims <- model$used_args$param.lims
  beta0.known <- model$used_args$beta0.known
  mybeta <- model$used_args$mybeta
  l <- model$used_args$l
  iso <- model$used_args$iso
  nugget <- model$used_args$nugget
  ncores <- model$used_args$ncores
  gradient  <- model$used_args$gradient
  if (is.null(H.known)) H <- model$estiP$H
  else H <- H.known
  if (any(is.na(y))){
    init <- model$estiP
    Ki <- chol2inv(chol(cov_gen(x1 = X, t1 = meshT, phi1sq = init$phi1sq, 
                                phi2sq = init$phi2sq, sigma1sq = init$sigma1sq,
                                sigma2sq = init$sigma2sq, l = l, covtype = covtype,
                                H = H, iso = iso, nugget = nugget)))
    used_args <- model$used_args 
    return(list(X = X, meshT = meshT, Y = Y, estiP = estiP, regF = regF,
                Ki = Ki, IMSPE_vars = IMSPE_vars,
                used_args = list(covtype = covtype, trendtype = trendtype,
                                 trend.pol = trend.pol,
                                 interaction = interaction, H.known = H.known, 
                                 param.known = param.known,
                                 sep.sigmasq = sep.sigmasq,
                                 param.lims = param.lims, 
                                 beta0.known = beta0.known,
                                 mybeta = mybeta, l = l, iso = iso,
                                 IMSPE_init = IMSPE_init, nugget = nugget,
                                 ncores = ncores, gradient = gradient,
                                 init = init)))
  }
  if (param.estim){
    return(MuFiMeshGP(X = X, meshT = meshT, Y = Y, covtype = covtype,
                      trendtype = trendtype, trend.pol = trend.pol,
                      interaction = interaction, H.known = H.known,
                      param.known = param.known, sep.sigmasq = sep.sigmasq,
                      param.lims = param.lims, beta0.known = beta0.known,
                      mybeta = mybeta, l = l, iso = iso, nugget = nugget,
                      ncores = ncores, gradient = gradient, init = init))
  } else {
    Ki <- chol2inv(chol(cov_gen(x1 = X, t1 = meshT, phi1sq = init$phi1sq, 
                                phi2sq = init$phi2sq, sigma1sq = init$sigma1sq,
                                sigma2sq = init$sigma2sq, l = l,
                                covtype = covtype, H = H, iso = iso,
                                nugget = nugget)))
    return(list(X = X, meshT = meshT, Y = Y, estiP = estiP, regF = regF,
                Ki = Ki, 
                used_args = list(covtype = covtype, trendtype = trendtype,
                                 trend.pol = trend.pol,
                                 interaction = interaction, H.known = H.known, 
                                 param.known = param.known,
                                 sep.sigmasq = sep.sigmasq,
                                 param.lims = param.lims, 
                                 beta0.known = beta0.known,
                                 mybeta = mybeta, l = l, iso = iso,
                                 nugget = nugget,
                                 ncores = ncores, gradient = gradient,
                                 init = init)))
  }
}