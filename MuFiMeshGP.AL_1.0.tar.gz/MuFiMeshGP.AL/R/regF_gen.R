################
### regF_gen ###
################

spat.int <- function(x){
  spat_int <- matrix(NA, nrow(x), ncol = choose(ncol(x),2))
  ind <- matrix(NA, nrow = ncol(spat_int), ncol = 2)
  count <- 1
  for (i in 1:(ncol(x)-1)){
    ind[count:(count+ncol(x)-i-1),] <- cbind(rep(i,(ncol(x)-i)),
                                             (i+1):(ncol(x)))
    count <- count + ncol(x)-i
  }
  for (i in 1:ncol(spat_int)){
    spat_int[,i] <- (2*x[,ind[i,1]]-1)*(2*x[,ind[i,2]]-1)
  }
  return(spat_int)
}

# Using Legendre polymonials for input space

regF_gen <- function(trend.pol, interaction, l, d){
  if (is.null(trend.pol)){
    if (is.null(interaction)){
      stop("OK must be used if trend.pol and interaction are NULL.")
    }else if (interaction == "linear"){
      regF <- function(x,t) return((2*x-1)*t^(l/2))
    }else if (interaction == "quadratic"){
      regF <- function(x,t){
        d <- ncol(x)
        if (d >= 2)
          return(cbind((2*x-1)*t^(l/2), (6*x^2-6*x+1)*t^(l/2),
                       spat.int(x)*t^(l/2)))
        else 
          return(cbind((2*x-1)*t^(l/2), (6*x^2-6*x+1)*t^(l/2)))
      }
    } else stop("interaction must be: NULL, 'linear', or 'quadratic'")
  } else if (trend.pol == "linear"){
    if (is.null(interaction)){
      regF <- function(x,t) return(2*x-1)
    } else if (interaction == "linear"){
      regF <- function(x,t) return(cbind(2*x-1, (2*x-1)*t^(l/2)))
    } else if (interaction == "quadratic"){
      regF <- function(x,t){
        d <- ncol(x)
        if (d >= 2)
          return(cbind(2*x-1, (2*x-1)*t^(l/2),
                       (6*x^2-6*x+1)*t^(l/2),
                       spat.int(x)*t^(l/2)))
        else 
          return(cbind(2*x-1, (2*x-1)*t^(l/2),
                       (6*x^2-6*x+1)*t^(l/2)))
      }
    } else stop("interaction must be: NULL, 'linear', or 'quadratic'")
  } else if (trend.pol == "quadratic"){
    if (is.null(interaction)){
      regF <- function(x,t){
        d <- ncol(x)
        if (d >= 2)
          return(cbind(2*x-1, 6*x^2-6*x+1, spat.int(x)))
        else 
          return(cbind(2*x-1, 6*x^2-6*x+1))
      }
    } else if (interaction == "linear"){
      regF <- function(x,t){
        d <- ncol(x)
        if (d >= 2)
          return(cbind(2*x-1, 6*x^2-6*x+1, spat.int(x),
                       (2*x-1)*t^(l/2)))
        else 
          return(cbind(2*x-1, 6*x^2-6*x+1,
                       (2*x-1)*t^(l/2)))
      }
    } else if (interaction == "quadratic"){
      regF <- function(x,t){
        d <- ncol(x)
        if (d >= 2)
          return(cbind(2*x-1, 6*x^2-6*x+1, spat.int(x),
                       (2*x-1)*t^(l/2),
                       (6*x^2-6*x+1)*t^(l/2),
                       spat.int(x)*t^(l/2)))
        else 
          return(cbind(2*x-1, 6*x^2-6*x+1,
                       (2*x-1)*t^(l/2),
                       (6*x^2-6*x+1)*t^(l/2)))
      }
    } else stop("interaction must be: NULL, 'linear', or 'quadratic'")
  } else stop("trend.pol must be: NULL, 'linear', or 'quadratic'")
  return(regF)
}
