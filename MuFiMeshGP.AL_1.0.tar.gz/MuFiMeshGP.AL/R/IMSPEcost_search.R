########################
### IMSPEcost_search ###
########################

IMSPEcost.search <- function(model, cost.func, cost.new, cost.switch = 0, t.min,
                             t.max, gr = FALSE, gr_cost.func = NULL,
                             new.level = TRUE, local.maxima = FALSE,
                             DesCand = NULL, Wijs = NULL, Hijs = NULL,
                             seed = NULL, ncores = 1,
                             control = list(factr = 1e8,
                                            multi.start.new = 20,
                                            multi.start.old = 5, maxit = 20,
                                            DesStart = NULL)){
  eps <- .Machine$double.eps
  if (is.null(seed)) 
    seed <- sample(1:2^15, 1)
  if (is.null(control)) 
    control <- list(multi.start.new = 20, multi.start.old = 5, maxit = 20)
  if (is.null(control$multi.start.new)) 
    control$multi.start.new <- 20
  if (is.null(control$multi.start.old)) 
    control$multi.start.old <- 5
  if (is.null(control$maxit)) 
    control$maxit <- 20
  d <- ncol(model$X)
  if (is.null(Wijs))
    Wijs <- Wij(x1 = model$X, phi1sq = model$estiP$phi1sq,
                sigma1sq = model$estiP$sigma1sq,
                covtype = model$used_args$covtype)
  if (model$used_args$trendtype %in% c("UK", "OK","TWY")){
    if (is.null(Hijs))
      Hijs <- Hij(mu = model$X, phi1sq = model$estiP$phi1sq, 
                  sigma1sq = model$estiP$sigma1sq, covtype = model$used_args$covtype,
                  trendtype = model$used_args$trendtype,
                  trend.pol = model$used_args$trend.pol,
                  interaction = model$used_args$interaction)
  }
  if (is.null(DesCand)) {
    mask <- ((model$meshT >= t.min)*(model$meshT <= t.max)) == 1
    t.uniq <- unique(model$meshT[mask])
    multi.old <- length(t.uniq)*control$multi.start.old
    if (!is.null(control$DesStart)) {
      DesStart.new <- control$DesStart
      DesStart.old <- matrix(control$DesStart[1:d], ncol = d)
    }
    else if (local.maxima){
      if (d > 2) print("local.maxima cannot be used for dimension bigger than
                       2.")
      else if (d==1){
        nrows <- 101
        XX <- matrix(seq(0,1, length.out = nrows), ncol = 1)
        mysd1 <- matrix(predict.MuFiMeshGP(model, XX, rep(0,nrow(XX)))$sd,
                        nrow = nrows)
        #Finding local maxima
        max.mask <- tail(order(c(0,which(diff(sign(diff(mysd1))) == -2) + 1,
                                 nrows)),4)
        XDes <- XX[max.mask,,drop = F]
        nDes <- nrow(XDes)
        # General case
        TDes.new <- min(model$meshT) + lhsDesign(4,1)$design *
          (max(model$meshT) - min(model$meshT))
        DesStart.new <- cbind(rep(XDes, 4), rep(TDes.new, each = nDes))
        if (multi.old > 0)
          DesStart.old <- cbind(matrix(rep(XDes, length(t.uniq)), ncol = d),
                                rep(t.uniq, each = nDes))
        else if (t.min == t.max)
          DesStart.new <- XDes
      }
      else if (d == 2){
        nrows <- 101
        XX <- seq(0,1, length.out = nrows)
        XXX <- as.matrix(expand.grid(XX,XX))
        mysd2 <- matrix(predict.MuFiMeshGP(model, XXX, rep(0,nrow(XXX)))$sd,
                        nrow = nrows)
        # Finding local maxima
        max.mask <- mysd2 > pmax(cbind(mysd2[,-1],0),
                                 cbind(0,mysd2[,-ncol(mysd2)]),
                                 rbind(mysd2[-1,],0),
                                 rbind(0,mysd2[-nrow(mysd2),]))
        XDes <- XXX[which(max.mask),]
        nDes <- nrow(XDes)
        # General case
        TDes.new <- min(model$meshT) + maximinLHS(4,1) * (max(model$meshT) - min(model$meshT))
        DesStart.new <- cbind(matrix(rep(t(XDes), 4), ncol=d, byrow = T), rep(TDes.new, each = nDes))
        if (multi.old > 0)
          DesStart.old <- cbind(matrix(rep(t(XDes), length(t.uniq)), ncol = d, byrow = T),
                                rep(t.uniq, each = nDes))
        else if (t.min == t.max)
          DesStart.new <- XDes
      }
    }
    else {
      DesStart.new <- maximinLHS(control$multi.start.new, d+1)
      corners <- matrix(as.numeric(as.matrix(do.call(expand.grid,
                                                     replicate(d+1, c(0,1), simplify = F)))),
                        ncol = d+1)
      DesStart.new <- rbind(DesStart.new,corners)
      DesStart.new[,d+1] <- min(model$meshT) + DesStart.new[,d+1] *
                                        (max(model$meshT) - min(model$meshT))
      if (multi.old > 0){
        DesStart.old <- maximinLHS(multi.old, d+1)
        DesStart.old[,d+1] <- rep(t.uniq, control$multi.start.old)
      }
      else if (t.min == t.max){
        multi.new <- control$multi.start.old*length(t.uniq)
        DesStart.new <- maximinLHS(multi.new, d+1)
        DesStart.new[,d+1] <- rep(t.uniq,control$multi.start.old)
      }
    }
  if (new.level && t.min != t.max){
    fn <- function(par) 
      return(crit_IMSPEcost.new(Des = par, model = model, cost.func = cost.func,
                                cost.new = cost.new, cost.switch = cost.switch,
                                Wijs = Wijs, Hijs = Hijs))
    if (gr) {
      gr <- function(par){
        return(grad_crit_IMSPEcost.new(Des = par, model = model,
                                       cost.func = cost.func,
                                       cost.new = cost.new,
                                       cost.switch = cost.switch,
                                       gr_cost.func = gr_cost.func,
                                       Wijs = Wijs, Hijs = Hijs))
      }
    }
    else gr <- NULL
      local_opt_fun.new <- function(i) {
        out <- optim(DesStart.new[i,], fn = fn,
                     gr = gr, method = "L-BFGS-B",
                     lower = c(rep(eps, d),t.min) , 
                     upper = c(rep(1, d), t.max), 
                     control = list(maxit = control$maxit, fnscale = -1))
        return(out)
      }
      all_res.new <- mclapply(1:nrow(DesStart.new), local_opt_fun.new, mc.cores = ncores)
      res_max.new <- which.max(Reduce(c, lapply(all_res.new, function(x) x$value)))
      par.new <- drop(all_res.new[[res_max.new]]$par)
      res.new <- list(par = par.new, value = all_res.new[[res_max.new]]$value, 
                      new = TRUE, id = NULL)
    }
    else if (!new.level && multi.old > 0){
      local_opt_fun.old <- function(i) {
        out <- optim(DesStart.old[i,1:d],crit_IMSPEcost.old,
                     method = "L-BFGS-B", 
                     lower = rep(eps, d), 
                     upper = rep(1, d),
                     t = DesStart.old[i,d+1], Wijs = Wijs, Hijs = Hijs,
                     model = model, cost.func = cost.func,
                     cost.switch = cost.switch, 
                     control = list(maxit = control$maxit, fnscale = -1,
                                    factr = control$factr))
        return(out)
      }
      all_res.old <- mclapply(1:nrow(DesStart.old), local_opt_fun.old, mc.cores = ncores)
      res_max.old <- which.max(Reduce(c, lapply(all_res.old, function(x) x$value)))
      par.old <- c(drop(all_res.old[[res_max.old]]$par),DesStart.old[res_max.old, d+1])
      res.old <- list(par = par.old, value = all_res.old[[res_max.old]]$value, 
                      new = FALSE, id = NULL)
    }
    else if (t.min == t.max){
      local_opt_fun.new <- function(i) {
        out <- optim(DesStart.new[i,], crit_IMSPEcost.old, method = "L-BFGS-B",
                     lower = rep(eps, d), 
                     upper = rep(1, d), 
                     t = t.max, Wijs = Wijs, Hijs = Hijs, model = model,
                     cost.func = cost.func, cost.switch = cost.switch,
                     control = list(maxit = control$maxit, fnscale = 1))
        return(out)
      }
      all_res.new <- mclapply(1:nrow(DesStart.new), local_opt_fun.new, mc.cores = ncores)
      res_max.new <- which.max(Reduce(c, lapply(all_res.new, function(x) x$value)))
      par.new <- c(drop(all_res.new[[res_max.new]]$par), t.max)
      res.new <- list(par = par.new, value = all_res.new[[res_max.new]]$value, 
                      new = TRUE, id = NULL)
    }
    if (multi.old == 0)
      res <- res.new
    else if (!new.level)
      res <- res.old
    else 
      res <- res.new
    return(res)
    }
  # Needs to be adapted later (case when we use DesCand)
  else {
    crit_IMSPEcost_mcl <- function(i, model, Wijs, DesCand) {
      crit_IMSPEcost.new(Des = DesCand[i,], model = model, 
                         cost.func = cost.func, cost.new = cost.new, 
                         cost.switch = cost.switch, Wijs = Wijs)
    }
    res <- unlist(mclapply(1:nrow(DesCand), crit_IMSPEcost_mcl, 
                           DesCand = DesCand, Wijs = Wijs,
                           model = model, mc.cores = ncores))
    tmp <- which(duplicated(rbind(cbind(model$X, model$meshT),
                                  DesCand[which.min(res), , drop = FALSE]), 
                            fromLast = TRUE))
    if (length(tmp) > 0) 
      return(list(par = DesCand[which.min(res), , drop = FALSE], 
                  value = min(res), new = FALSE, id = tmp))
    return(list(par = DesCand[which.min(res), , drop = FALSE], 
                value = min(res), new = TRUE, id = NULL))
  }
}
