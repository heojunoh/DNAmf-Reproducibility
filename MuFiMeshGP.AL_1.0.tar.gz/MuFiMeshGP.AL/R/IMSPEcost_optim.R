#######################
### IMSPEcost_optim ###
#######################

IMSPEcost_optim <- function(model, h = 2, cost.func, cost.new, cost.switch = 0,
                            t.min, t.max, local.maxima = FALSE, DesCand = NULL,
                            Wijs = NULL, seed = NULL, ncores = 1, 
                             control = list(tol_dist = 1e-06, tol_diff = 1e-06,
                                            multi.start.new = 20,
                                            multi.start.old = 5,
                                            maxit = 100, maximin = TRUE,
                                            DesStart = NULL)){
  mask <- ((model$meshT > t.min)*(model$meshT < t.max)) == 1
  t.uniq <- unique(model$meshT[mask])
  if (is.null(Wijs)) 
    Wijs <- Wij(mu1 = model$X, phi1sq = model$estiP$phi1sq,
                sigma1sq = model$estiP$sigma1sq, covtype = model$covtype)
  if (length(t.uniq) == 0){
    IMSPE_0 <- IMSPEcost.search(model = model, cost.func = cost.func,
                                cost.new = cost.new, cost.switch = cost.switch,
                                t.min = t.min, t.max = t.max,
                                local.maxima = local.maxima,
                                DesCand = DesCand, Wijs = Wijs, ncores = ncores,
                                control = control)
    return(IMSPE_0)
  }
  std_path = list()
  names_std_path <- c()
  if (h == 0)
    paths <- list(path0 = list(step1 = list()), path1 = list(step1 = list()))
  else {
  for (i in 1:(h+1)){
    std_path <- append(std_path, list(par = NULL))
    names_std_path <- c(names_std_path, paste0("step",i))
  }
  names(std_path) <- names_std_path
  paths = list()
  names_paths = c()
  for (i in 0:h){
    paths <- append(paths, list(std_path))
    names_paths <- c(names_paths, paste0("path",i))
    paths[[i+1]]$cum_value <- 0
  }
  names(paths) <- names_paths
  }
  d <- ncol(model$X)
  if (max(rbind(model$X, DesCand)) > 1) 
    stop("IMSPE works only with [0,1]^d domain for now.")
  if (max(rbind(model$X, DesCand)) < 0) 
    stop("IMSPE works only with [0,1]^d domain for now.")
  IMSPE_A <- IMSPEcost.search(model = model, cost.func = cost.func,
                              cost.new = cost.new, cost.switch = cost.switch, 
                              t.min = t.min, t.max = t.max,
                              local.maxima = local.maxima, DesCand = DesCand,
                              Wijs = Wijs, ncores = ncores, control = control) 
  new_designA <- IMSPE_A$par
  paths[[1]][[1]] <- IMSPE_A
  paths[[1]]$cum_value <- IMSPE_A$value
  best_path <- paths[[1]]
  best_path_nb <- 0
  if (h < 0)
    return("h must be non-negative")
  else {
    newmodelA <- model
    WijsA <- Wijs
    if (h > 0){
      for (i in 1:h) {
        newWijs <- Wij(mu1 = newmodelA$X, mu2 = matrix(IMSPE_A$par[1:d], 
                                                       nrow = 1), 
                       phi1sq = newmodelA$estiP$phi1sq,
                       sigma1sq = newmodelA$estiP$sigma1sq,
                       covtype = newmodelA$covtype)
        WijsA <- cbind(WijsA, newWijs)
        WijsA <- rbind(WijsA, cbind(t(newWijs),
                                    Wij(matrix(IMSPE_A$par[1:d], nrow = 1),
                                        phi1sq = newmodelA$estiP$phi1sq,
                                        sigma1sq = newmodelA$estiP$sigma1sq,
                                        covtype = newmodelA$covtype)))
        newmodelA <- update.MuFiMeshGP(model = newmodelA, x = IMSPE_A$par[1:d],
                                       t = IMSPE_A$par[d+1], y = NA)
        IMSPE_A <- IMSPEcost.search(model = newmodelA, new.level = FALSE,
                                    cost.func = cost.func, cost.new = cost.new,
                                    cost.switch = cost.switch, t.min = t.min,
                                    t.max = t.max, local.maxima = local.maxima,
                                    DesCand = DesCand, Wijs = WijsA,
                                    ncores = ncores, control = control)
        paths[[1]][[i+1]] <- IMSPE_A
        paths[[1]]$cum_value <- paths[[1]]$cum_value + IMSPE_A$value
      }
      best_path <- paths[[1]]
      best_path_nb <- 0
    }
  }
  newmodelB <- model
  WijsB <- Wijs
  if (h == 0) {
    IMSPE_B <- IMSPEcost.search(model = newmodelB, new.level = FALSE, cost.func = cost.func, cost.new = cost.new,
                            cost.switch = cost.switch, t.min = t.min, t.max = t.max, local.maxima = local.maxima,
                            DesCand = DesCand, Wijs = Wijs, ncores = ncores, control = control)
    paths[[2]][[1]] <- IMSPE_B
    paths[[2]]$cum_value <- IMSPE_B$value
    if (best_path$cum_value < paths[[2]]$cum_value){
      best_path <- paths[[2]]
      best_path_nb <- 1
    }
  }
  else {
    for (i in 1:h) {
      IMSPE_B <- IMSPEcost.search(model = newmodelB, new.level = FALSE, cost.func = cost.func, cost.new = cost.new,
                                  cost.switch = cost.switch, t.min = t.min, t.max = t.max, local.maxima = local.maxima,
                                  DesCand = DesCand, Wijs = WijsB, ncores = ncores, control = control)
      new_designB <- IMSPE_B$par
      for (j in i:h){
        paths[[j+1]][[i]] <- IMSPE_B
        paths[[j+1]]$cum_value <- paths[[j+1]]$cum_value + IMSPE_B$value
      }
      newWijs <- Wij(mu1 = newmodelB$X, mu2 = matrix(IMSPE_B$par[1:d], nrow = 1), 
                     phi1sq = newmodelB$estiP$phi1sq, sigma1sq = newmodelB$estiP$sigma1sq, covtype = newmodelB$covtype)
      WijsB <- cbind(WijsB, newWijs)
      WijsB <- rbind(WijsB, cbind(t(newWijs), Wij(matrix(IMSPE_B$par[1:d], nrow = 1), phi1sq = newmodelB$estiP$phi1sq, 
                                           sigma1sq = newmodelB$estiP$sigma1sq, covtype = newmodelB$covtype)))
      newmodelB <- update.MuFiMeshGP(model = newmodelB, x = IMSPE_B$par[1:d], 
                                     t = IMSPE_B$par[d+1], y = NA)
      IMSPE_C <- IMSPEcost.search(model = newmodelB, cost.func = cost.func, cost.new = cost.new,
                                  cost.switch = cost.switch, t.min = t.min, t.max = t.max, local.maxima = local.maxima,
                                  DesCand = DesCand, Wijs = WijsB, ncores = ncores, control = control)
      paths[[i+1]][[i+1]] <- IMSPE_C
      paths[[i+1]]$cum_value <- paths[[i+1]]$cum_value + IMSPE_C$value
      if (i < h) {
        newmodelC <- newmodelB
        WijsC <- WijsB
        for (j in (i+1):h) {
          newWijs <- Wij(mu1 = newmodelC$X, mu2 = matrix(IMSPE_C$par[1:d], nrow = 1), phi1sq = newmodelC$estiP$phi1sq,
                         sigma1sq = newmodelC$estiP$sigma1sq, covtype = newmodelC$covtype)
          WijsC <- cbind(WijsC, newWijs)
          WijsC <- rbind(WijsC, cbind(t(newWijs), Wij(mu1 = matrix(IMSPE_C$par[1:d], nrow = 1), phi1sq = newmodelC$estiP$phi1sq,
                                               sigma1sq = newmodelC$estiP$sigma1sq, covtype = newmodelC$covtype)))
          newmodelC <- update.MuFiMeshGP(model = newmodelC, x = IMSPE_C$par[1:d], 
                              t = IMSPE_C$par[d+1], y = NA)
          IMSPE_C <- IMSPEcost.search(model = newmodelC, new.level = FALSE, cost.func = cost.func, cost.new = cost.new,
                                      cost.switch = cost.switch, t.min = t.min, t.max = t.max, local.maxima = local.maxima,
                                      DesCand = DesCand, Wijs = WijsC, ncores = ncores, control = control)
          paths[[i+1]][[j+1]] <- IMSPE_C
          paths[[i+1]]$cum_value <- paths[[i+1]]$cum_value + IMSPE_C$value
        }
      }
      if (paths[[i+1]]$cum_value > best_path$cum_value){
        best_path <- paths[[i+1]]
        best_path_nb <- i
      }
    }
  }
  return(list(par = best_path[[1]]$par, cum_value = best_path$cum_value, new = best_path[[1]]$new, best_path_nb = best_path_nb, best_path = best_path, paths = paths))
}