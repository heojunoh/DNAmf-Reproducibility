##########################
### predict.MuFiMeshGP ###
##########################

predict.MuFiMeshGP <- function(model, x, t){
  X <- model$X
  Y <- model$Y
  meshT <- model$meshT
  phi1sq <- model$estiP$phi1sq
  phi2sq <- model$estiP$phi2sq
  sigma1sq <- model$estiP$sigma1sq
  sigma2sq <- model$estiP$sigma2sq
  l <- model$l
  nugget <- model$used_args$nugget
  if (is.null(model$used_args$H.known)) H <- model$estiP$H
  else H <- model$used_args$H.known
  if (model$used_args$trendtype == "SK")
    beta0.known = model$used_args$beta0.known
  nrowX <- nrow(X)
  d <- ncol(X)
  Ki <- model$Ki
  kn <- cov_gen(x1 = X, x2 = x, t1 = meshT, t2 = t, phi1sq = phi1sq,
                phi2sq = phi2sq, sigma1sq = sigma1sq, sigma2sq = sigma2sq,
                l = model$used_args$l, covtype = model$used_args$covtype, H = H,
                iso = model$used_args$iso, nugget = nugget)
  k <- diag(cov_gen(x1 = x, t1 = t, phi1sq = phi1sq, phi2sq = phi2sq,
                    sigma1sq = sigma1sq, sigma2sq = sigma2sq,
                    l = model$used_args$l, covtype = model$used_args$covtype,
                    H = H, iso = model$used_args$iso, nugget = nugget))
  if (model$used_args$trendtype == "SK"){
    myCalm11 <- Y - beta0.known
    mean <- beta0.known + crossprod(kn,crossprod(Ki,myCalm11))
    sd <- sqrt(ifelse(k - colSums(kn*crossprod(Ki,kn)) >= 0,
                      k - colSums(kn*crossprod(Ki,kn)), 0))
  }
  if (model$used_args$trendtype == "OK"){
    beta <- c(model$estiP$beta)
    myregF <- matrix(1,nrow = nrowX, ncol = 1)
    myregf <- matrix(rep(1,nrow(x)), nrow = 1)
    myCalm11 <- Y - myregF %*% beta
    mean <- crossprod(myregf, beta) + crossprod(kn,crossprod(Ki,myCalm11))
    Var1 <- ifelse(k - colSums(kn*crossprod(Ki,kn)) >= 0,
                   k - colSums(kn*crossprod(Ki,kn)), 0)
    gamma <- myregf - crossprod(myregF,crossprod(Ki,kn))
    M <- crossprod(myregF,crossprod(Ki, myregF))
    Var2 <- ifelse(colSums(gamma*solve(M, gamma)) >= 0,
                   colSums(gamma*solve(M, gamma)),0)
    sd <- sqrt(Var1 + Var2)
  }
  if (model$used_args$trendtype %in% c("UK","TWY")){
    beta <- model$estiP$beta
    myregF <- cbind(rep(1,nrowX),model$regF(X,meshT))
    myregf <- t(cbind(rep(1,nrow(x)),model$regF(x, t)))
    myCalm11 <- Y - myregF %*% beta
    mean <- crossprod(myregf, beta) + crossprod(kn,crossprod(Ki,myCalm11))
    Var1 <- ifelse(k - colSums(kn*crossprod(Ki,kn)) >= 0,
                   k - colSums(kn*crossprod(Ki,kn)), 0)
    gamma <- myregf - crossprod(myregF,crossprod(Ki,kn))
    M <- crossprod(myregF,crossprod(Ki, myregF))
    Var2 <- ifelse(colSums(gamma*solve(M, gamma)) >= 0,
                   colSums(gamma*solve(M, gamma)),0)
    sd <- sqrt(Var1 + Var2)
  }
  return(list(mean = mean, sd = sd))
}
