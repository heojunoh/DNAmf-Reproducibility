##################
### MuFiMeshGP ###
##################

MuFiMeshGP <-  function(X, meshT, Y, covtype = "Gaussian", trendtype = "OK",
                        trend.pol = NULL, interaction = NULL,
                        H.known = NULL, param.known = NULL, sep.sigmasq = F,
                        param.lims = NULL, beta0.known = NULL, mybeta = NULL, 
                        l = 4, iso = FALSE, nugget = 1e-4,
                        Gijs = NULL,
                        ncores = 1, gradient = FALSE, init = NULL){
  eps <- sqrt(.Machine$double.eps)
  n <- nrow(X)
  d <- ncol(X)
  regF <- NULL
  if (is.null(H.known)) myH <- 0.5
  else myH <- H.known
  if (trendtype == "SK" & is.null(beta0.known)){
    stop("beta0.known must be specified for SK")
  } else if (trendtype == "SK" & !is.null(beta0.known)){
    p <- 0
  } else if (trendtype == "OK") {
    myregF <- matrix(1,nrow = n, ncol = 1)
    trend.pol <- NULL
    interaction <- NULL
    p <- 1
    if (is.null(Gijs))
      Gijs <- Gij(d = ncol(X), trendtype = trendtype,
                  trend.pol = trend.pol, interaction = interaction)
  }
  else if (trendtype == "TWY") {
    regF <- function(x,t) return(matrix(t^(l/2), ncol = 1))
    myregF <- cbind(rep(1,n),regF(X,meshT))
    p <- dim(myregF)[2]
    if (is.null(Gijs))
      Gijs <- Gij(d = ncol(X), trendtype = trendtype,
                  trend.pol = trend.pol, interaction = interaction)
  }
  else if (trendtype == "UK") {
    regF <- regF_gen(trend.pol = trend.pol, interaction = interaction, l = l)
    myregF <- cbind(rep(1,n),regF(X,meshT))
    p <- dim(myregF)[2]
    if (is.null(Gijs))
      Gijs <- Gij(d = ncol(X), trendtype = trendtype,
                  trend.pol = trend.pol, interaction = interaction)
  }
  bounds <- hetGP:::auto_bounds(cbind(X,meshT))
  if (is.null(param.lims)){
      lower_phisq <- as.numeric(1/bounds$upper[1:d])
      upper_phisq <- as.numeric(1/bounds$lower[1:d])
  }
  else {
    tryCatch(
      expr = {
        lower_phisq <- param.lims[1]
        upper_phisq <- param.lims[2]
      }, error = function(e){          
        print("param.lims must be a vector of length 2.")
      }
    )
  }
  sq.int <- max(Y) - min(Y)
  if (is.null(init)){
    myphi1sq <- sqrt(lower_phisq*upper_phisq)
    myphi2sq <- myphi1sq
    if (!sep.sigmasq){
      mytausq <- 1/mean(meshT)^l
    }
    else {
      mysigma1sq <- var(Y)/10 
      mysigma2sq <- mysigma1sq/mean(meshT)^l
    }
  }  
  else {
    if (!iso && d > 1){
      myphi1sq <- init$phi1sq
      myphi2sq <- init$phi2sq
    }
    else {
      myphi1sq <- init$phi1sq[1]
      myphi2sq <- init$phi2sq[1]
    }
    if (!sep.sigmasq){
      mytausq <- init$sigma2sq/init$sigma1sq
    }
    else {
      mysigma1sq <- init$sigma1sq
      mysigma2sq <- init$sigma2sq
    }
    if (is.null(H.known)) myH <- init$H
  }
  envtmp <- environment()
  if (trendtype == "SK"){
    fn <- function(pars,env){
      loglik <- myMLE_SK(pars, X, meshT, Y, l, covtype, beta0.known, H.known,
                         sep.sigmasq, iso = iso, nugget = nugget)
      if (!is.null(env) && !is.na(loglik)) {
        if (is.null(env$min_loglik) || loglik > env$min_loglik) {
          env$min_loglik <- loglik
          env$arg_min <- pars
        }
      }
      return(loglik)
    }
    if (gradient){
      gr <- function(pars,env) {
        gr_loglik <- gr_myMLE_SK(pars, X, meshT, Y, l, covtype, beta0.known,
                                 H.known, sep.sigmasq, iso = iso, nugget = nugget)
        return(gr_loglik)
      }
    } else gr <- NULL
    if (!sep.sigmasq){
      lower.params <- log(c(lower_phisq, lower_phisq, 1e-4/max(meshT)^l))
      upper.params <- log(c(rep(1e3, 2*d), 1e4/max(meshT)^l))
    } else {
      lower.params <- log(c(lower_phisq, lower_phisq, 
                        1e-2*var(Y), 1e-2*var(Y)/max(meshT)^l))
      upper.params <- log(c(rep(1e3, 2*d), 1e2*var(Y),
                            1e2*var(Y)/max(meshT)^l))
    }
  } else if (trendtype == "OK"){
    fn <- function(pars,env){
      loglik <- myRMLE_OK(pars, X, meshT, Y, myregF, l, covtype, H.known,
                          sep.sigmasq, iso = iso, nugget = nugget)
      if (!is.null(env) && !is.na(loglik)) {
        if (is.null(env$min_loglik) || loglik > env$min_loglik) {
          env$min_loglik <- loglik
          env$arg_min <- pars
        }
      }
      return(loglik)
    }
    if (gradient){
      gr <- function(pars,env) {
        gr_loglik <- gr_myRMLE_OK(pars, X, meshT, Y, myregF, l, covtype, H.known,
                                  sep.sigmasq, iso = iso, nugget = nugget)
        return(gr_loglik)
      }
    } else gr <- NULL
    if (!sep.sigmasq){
      lower.params <- log(c(lower_phisq, lower_phisq, 1e-4/max(meshT)^l))
      upper.params <- log(c(rep(1e3, 2*d), 1e4/max(meshT)^l))
    } else {
      lower.params <- log(c(lower_phisq, lower_phisq, 
                        1e-2*var(Y), 1e-2*var(Y)/max(meshT)^l))
      upper.params <- log(c(rep(1e3, 2*d),  1e2*var(Y), 
                            1e2*var(Y)/max(meshT)^l))
    }
  } else if (trendtype == "TWY"){
    fn <- function(pars,env){
      loglik <- myRMLE_UK(pars, X, meshT, Y, myregF, l, covtype, H.known,
                          sep.sigmasq, iso = iso, nugget = nugget)
      if (!is.null(env) && !is.na(loglik)) {
        if (is.null(env$min_loglik) || loglik > env$min_loglik) {
          env$min_loglik <- loglik
          env$arg_min <- pars
        }
      }
      return(loglik)
    }
    if (gradient){
      gr <- function(pars,env) {
        gr_loglik <- gr_myRMLE_UK(pars, X, meshT, Y, myregF, l, covtype, H.known,
                                  sep.sigmasq, iso = iso, nugget = nugget)
        return(gr_loglik)
      }
    }
    else gr <- NULL
    if (!sep.sigmasq){
      lower.params <- log(c(lower_phisq, lower_phisq, 1e-4/max(meshT)^l))
      upper.params <- log(c(rep(1e3, 2*d), 1e4/max(meshT)^l))
    } else {
      lower.params <-log(c(lower_phisq, lower_phisq, 
                           1e-2*var(Y), 1e-2*var(Y)/max(meshT)^l))
      upper.params <- log(c(rep(1e3, 2*d), 1e2*var(Y),
                            1e2*var(Y)/max(meshT)^l))
    }
  } else if (trendtype == "UK"){
    fn <- function(pars,env){
      loglik <- myRMLE_UK(pars, X, meshT, Y, myregF, l, covtype, H.known,
                          sep.sigmasq, iso = iso, nugget = nugget)
      if (!is.null(env) && !is.na(loglik)) {
        if (is.null(env$min_loglik) || loglik > env$min_loglik) {
          env$min_loglik <- loglik
          env$arg_min <- pars
        }
      }
      return(loglik)
    }
    if (gradient){
      gr <- function(pars,env) {
        gr_loglik <- gr_myRMLE_UK(pars, X, meshT, Y, myregF, l, covtype, H.known,
                                  sep.sigmasq, iso = iso, nugget = nugget)
        return(gr_loglik)
      }
    }
    else gr <- NULL
    if (!sep.sigmasq){
      lower.params <- log(c(lower_phisq, lower_phisq, 1e-4/max(meshT)^l))
      upper.params <- log(c(rep(1e3, 2*d), 1e4/max(meshT)^l))
    } else {
      lower.params <- log(c(lower_phisq, lower_phisq,
                        1e-2*var(Y), 1e-2*var(Y)/max(meshT)^l))
      upper.params <- log(c(rep(1e3, 2*d), 1e2*var(Y),
                            1e2*var(Y)/max(meshT)^l))
    }
  }
  if (is.null(H.known) && is.null(param.known)){
    if (!sep.sigmasq){
      pars <- c(log(c(myphi1sq, myphi2sq, mytausq)), myH)
    } else {
      pars <- c(log(c(myphi1sq, myphi2sq, mysigma1sq, mysigma2sq)), myH)
    }
    lower.pars <- c(lower.params,eps)
    upper.pars <- c(upper.params,1)
  } else if (!is.null(H.known) && is.null(param.known)){
    if (!sep.sigmasq){
      pars <- log(c(myphi1sq, myphi2sq, mytausq))
    } else {
      pars <- log(c(myphi1sq, myphi2sq, mysigma1sq, mysigma2sq))
    }
    lower.pars <- lower.params
    upper.pars <- upper.params
  }
  if (is.null(H.known) || is.null(param.known)){
    res <- try(optim(pars, fn, method = "L-BFGS-B", 
                     lower = lower.pars, upper = upper.pars,
                     gr = gr, env = envtmp))
    if (is(res, "try-error")){ 
      res <- list(par = envtmp$arg_min, value = envtmp$min_loglik, 
                  counts = NA, message = "Optimization stopped due to NAs,
                  use best value so far")
    }
    parss <- res$par
    if (!iso){
      phi1sq <- exp(parss[1:d])
      phi2sq <- exp(parss[(d+1):(2*d)])
      if (!sep.sigmasq){
        tausq <- exp(parss[2*d+1])
        if (is.null(H.known)) H <- parss[2*d+2]
        else H <- H.known
      }
      else {
        sigma1sq <- exp(parss[2*d+1])
        sigma2sq <- exp(parss[2*d+2])
        if (is.null(H.known)) H <- parss[2*d+3]
        else H <- H.known
      }
    }
    else {
      phi1sq <- exp(rep(parss[1],d))
      phi2sq <- exp(rep(parss[2],d))
      if (!sep.sigmasq){
        tausq <- exp(parss[3])
        if (is.null(H.known)) H <- parss[4]
        else H <- H.known
      }
      else {
        sigma1sq <- exp(parss[3])
        sigma2sq <- exp(parss[4])
        if (is.null(H.known)) H <- parss[5]
        else H <- H.known
      }
    }
  }
  if (!is.null(H.known) && !is.null(param.known)){
    sep.sigmasq <- T
    if (!iso){
      phi1sq <- param.known[1:d]
      phi2sq <- param.known[(d+1):(2*d)]
      sigma1sq <- param.known[2*d+1]
      sigma2sq <- param.known[2*d+2]
      H <- H.known
    }
    else {
      phi1sq <- rep(param.known[1],d)
      phi2sq <- rep(param.known[2],d)
      sigma1sq <- param.known[3]
      sigma2sq <- param.known[4]
      H <- H.known
    }
  }
  if (!sep.sigmasq){
    myK <- cov_gen(x1 = X, t1 = meshT, phi1sq = phi1sq, phi2sq = phi2sq,
                   sigma1sq = 1, sigma2sq = tausq, l=l, covtype = covtype,
                   H = H, iso = iso, nugget = nugget)
  } else {
    myK <- cov_gen(x1 = X, t1 = meshT, phi1sq = phi1sq, phi2sq = phi2sq,
                   sigma1sq = sigma1sq, sigma2sq = sigma2sq, l=l, covtype = covtype,
                   H = H, iso = iso, nugget = nugget)
  }
  Ki <- chol2inv(chol(myK))
  if (trendtype %in% c("OK","UK","TWY")){
    myKiF <- Ki %*% myregF
    myW <- crossprod(myregF, myKiF)
    myWi <- chol2inv(chol(myW))
    beta <- tcrossprod(myWi, myKiF) %*% Y
  }
  if (!sep.sigmasq && is.null(param.known)){  
    if (trendtype == "SK") tmp <- Y
    else tmp <- Y - myregF %*% beta
    sigma1sq <- c(crossprod(tmp,Ki) %*% tmp)/(n-p)
    sigma2sq <- tausq*sigma1sq
    myK <- cov_gen(x1 = X, t1 = meshT, phi1sq = phi1sq, phi2sq = phi2sq,
                   sigma1sq = sigma1sq, sigma2sq = sigma2sq, l=l, covtype = covtype,
                   H = H, iso = iso, nugget = nugget)
    Ki <- chol2inv(chol(myK))
  }
  if (is.null(H.known)){
    if (trendtype == "SK"){
      estiP = list(phi1sq = phi1sq, phi2sq = phi2sq, sigma1sq = sigma1sq, 
                   sigma2sq = sigma2sq, H = H)
    }
    else if (trendtype %in% c("OK","UK","TWY")){
      estiP = list(phi1sq = phi1sq, phi2sq = phi2sq, sigma1sq = sigma1sq,
                   sigma2sq = sigma2sq, beta = beta, H = H)
    }
  }
  else {
    if (trendtype == "SK"){
      estiP = list(phi1sq = phi1sq, phi2sq = phi2sq, sigma1sq = sigma1sq, 
                   sigma2sq = sigma2sq)
    }
    else if (trendtype %in% c("OK","UK","TWY")){
      estiP = list(phi1sq = phi1sq, phi2sq = phi2sq, sigma1sq = sigma1sq,
                   sigma2sq = sigma2sq, beta = beta)
    }
  }
  MuFimodel <- list(X = X, meshT = meshT, Y = Y, 
                    estiP = estiP, regF = regF, Ki = Ki,
                    used_args = list(covtype = covtype, trendtype = trendtype,
                                     trend.pol = trend.pol,
                                     interaction = interaction, 
                                     H.known = H.known, 
                                     param.known = param.known,
                                     sep.sigmasq = sep.sigmasq,
                                     param.lims = param.lims,
                                     beta0.known = beta0.known,
                                     mybeta = mybeta, l = l, iso = iso,
                                     nugget = nugget, Gijs = Gijs,
                                     ncores = ncores, gradient = gradient,
                                     init = init))
  return(MuFimodel)
}
