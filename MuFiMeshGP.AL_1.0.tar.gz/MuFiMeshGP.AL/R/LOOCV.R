#############
### LOOCV ###
#############

CRPS <- function(y, mu, sd){
  crps <- sd*(2*dnorm((y-mu)/sd)+
                    (y-mu)/sd*
                    (2*pnorm((y-mu)/sd)-1)-
                    1/sqrt(pi))
  return(crps)
}

LOOCV <- function(model){
  X <- model$X
  meshT <- model$meshT
  Y <- model$Y
  Ki <- model$Ki
  l <- model$l
  if (model$trendtype == "SK"){
    beta0 <- model$used_args$beta0.known
    pred <- Y - (Ki %*% (Y - beta0))/diag(Ki)
    sd2 <- 1/diag(Ki)
    rmse <- mean((pred - Y)^2)
  }
  if (model$trendtype == "OK"){
    beta0 <- c(model$estiP$beta)
    pred <- Y - (Ki %*% (Y - beta0))/diag(Ki)
    sd2 <- 1/diag(Ki) - rowSums(Ki)^2/(diag(Ki)^2 * sum(Ki))
    rmse <- mean((pred - Y)^2)
  }
  if (model$trendtype == "UK"){
    beta <- model$estiP$beta
    myF <- cbind(rep(1,nrow(X)),model$regF(X,meshT))
    pred <- Y - (Ki %*% (Y - myF %*% beta))/diag(Ki)
    sd2 <- NULL
    rmse <- mean((pred - Y)^2)
  }
  return(list(pred = pred, sd2 = sd2, rmse = rmse))
}