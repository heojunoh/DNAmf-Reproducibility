#############
### myMLE ###
#############

myMLE_SK <- function(pars, X, meshT, Y, l, covtype, beta0.known, H.known,
                     sep.sigmasq, iso = FALSE, nugget = NULL) {
  d <- ncol(X)
  n <- nrow(X)
  if (is.null(H.known)){
    if (!iso){
      phi1sq <- exp(pars[1:d])
      phi2sq <- exp(pars[(d+1):(2*d)])
      if (!sep.sigmasq){
        sigma1sq <- 1
        sigma2sq <- exp(pars[2*d+1])
        H <- pars[2*d+2]
      } else {
        sigma1sq <- exp(pars[2*d+1])
        sigma2sq <- exp(pars[2*d+2])
        H <- pars[2*d+3]
      }
    }
    else {
      phi1sq <- exp(pars[1])
      phi2sq <- exp(pars[2])
      if (!sep.sigmasq){
        sigma1sq <- 1
        sigma2sq <- exp(pars[3])
        H <- pars[4]
      } else {
        sigma1sq <- exp(pars[3])
        sigma2sq <- exp(pars[4])
        H <- pars[5]
      }
    } 
  }
  else {
    H <- H.known
    if (!iso){
      phi1sq <- exp(pars[1:d])
      phi2sq <- exp(pars[(d+1):(2*d)])
      if (!sep.sigmasq){
        sigma1sq <- 1
        sigma2sq <- exp(pars[2*d+1])
      } else {
        sigma1sq <- exp(pars[2*d+1])
        sigma2sq <- exp(pars[2*d+2])
      }
    }
    else {
      phi1sq <- exp(pars[1])
      phi2sq <- exp(pars[2])
      if (!sep.sigmasq){
        sigma1sq <- 1
        sigma2sq <- exp(pars[3])
      } else {
        sigma1sq <- exp(pars[3])
        sigma2sq <- exp(pars[4])
      }
    } 
  }
  myK <- cov_gen(x1 = X, t1 = meshT, phi1sq = phi1sq, phi2sq = phi2sq,
                 sigma1sq = sigma1sq, sigma2sq = sigma2sq, l=l, 
                 covtype = covtype, H = H, iso = iso, nugget = nugget)
  myKi <- chol2inv(chol(myK))
  myval <- 1/2 * as.double(determinant(myK)$modulus) +
    n/2 * log(crossprod(Y - beta0.known, myKi %*% (Y - beta0.known)))
  return(c(myval))
}

myRMLE_OK <- function(pars, X, meshT, Y, myregF, l, covtype, H.known,
                      sep.sigmasq, iso = FALSE, nugget = NULL) {
  d <- ncol(X)
  p <- 1
  n <- nrow(X)
  if (is.null(H.known)){
    if (!iso){
      phi1sq <- exp(pars[1:d])
      phi2sq <- exp(pars[(d+1):(2*d)])
      if (!sep.sigmasq){
        sigma1sq <- 1
        sigma2sq <- exp(pars[2*d+1])
        H <- pars[2*d+2]
      } else {
        sigma1sq <- exp(pars[2*d+1])
        sigma2sq <- exp(pars[2*d+2])
        H <- pars[2*d+3]
      }
    }
    else {
      phi1sq <- exp(pars[1])
      phi2sq <- exp(pars[2])
      if (!sep.sigmasq){
        sigma1sq <- 1
        sigma2sq <- exp(pars[3])
        H <- pars[4]
      } else {
        sigma1sq <- exp(pars[3])
        sigma2sq <- exp(pars[4])
        H <- pars[5]
      }
    } 
  }
  else {
    H <- H.known
    if (!iso){
      phi1sq <- exp(pars[1:d])
      phi2sq <- exp(pars[(d+1):(2*d)])
      if (!sep.sigmasq){
        sigma1sq <- 1
        sigma2sq <- exp(pars[2*d+1])
      } else {
        sigma1sq <- exp(pars[2*d+1])
        sigma2sq <- exp(pars[2*d+2])
      }
    }
    else {
      phi1sq <- exp(pars[1])
      phi2sq <- exp(pars[2])
      if (!sep.sigmasq){
        sigma1sq <- 1
        sigma2sq <- exp(pars[3])
      } else {
        sigma1sq <- exp(pars[3])
        sigma2sq <- exp(pars[4])
      }
    } 
  }
  # Create contrasts
  Z <- crossprod(diag(x = 1, nrow = n) - 
                   tcrossprod(myregF %*% 
                                chol2inv(chol(crossprod(myregF, myregF))),
                                         myregF), Y)
  myK <- cov_gen(x1 = X, t1 = meshT, phi1sq = phi1sq, phi2sq = phi2sq,
                 sigma1sq = sigma1sq, sigma2sq = sigma2sq, l=l,
                 covtype = covtype, H = H, iso = iso, nugget = nugget)
  myKi <- chol2inv(chol(myK))
  myKiF <- myKi %*% myregF
  myW <- crossprod(myregF, myKiF)
  myWi <- chol2inv(chol(myW))
  myval <- 1/2 * as.double(determinant(myK)$modulus) +
           1/2 * as.double(determinant(myW)$modulus) +
           (n-p)/2 * log(crossprod(Z, (myKi -myKiF %*%
                                      tcrossprod(myWi, myKiF)) %*% Z))
  return(c(myval))
}

myRMLE_UK <- function(pars, X, meshT, Y, myregF, l, covtype, H.known,
                     sep.sigmasq, iso = FALSE, nugget = NULL) {
  d <- ncol(X)
  n <- nrow(X)
  p <- ncol(myregF)
  if (is.null(H.known)){
    if (!iso){
      phi1sq <- exp(pars[1:d])
      phi2sq <- exp(pars[(d+1):(2*d)])
      if (!sep.sigmasq){
        sigma1sq <- 1
        sigma2sq <- exp(pars[2*d+1])
        H <- pars[2*d+2]
      } else {
        sigma1sq <- exp(pars[2*d+1])
        sigma2sq <- exp(pars[2*d+2])
        H <- pars[2*d+3]
      }
    }
    else {
      phi1sq <- exp(pars[1])
      phi2sq <- exp(pars[2])
      if (!sep.sigmasq){
        sigma1sq <- 1
        sigma2sq <- exp(pars[3])
        H <- pars[4]
      } else {
        sigma1sq <- exp(pars[3])
        sigma2sq <- exp(pars[4])
        H <- pars[5]
      }
    } 
  }
  else {
    H <- H.known
    if (!iso){
      phi1sq <- exp(pars[1:d])
      phi2sq <- exp(pars[(d+1):(2*d)])
      if (!sep.sigmasq){
        sigma1sq <- 1
        sigma2sq <- exp(pars[2*d+1])
      } else {
        sigma1sq <- exp(pars[2*d+1])
        sigma2sq <- exp(pars[2*d+2])
      }
    }
    else {
      phi1sq <- exp(pars[1])
      phi2sq <- exp(pars[2])
      if (!sep.sigmasq){
        sigma1sq <- 1
        sigma2sq <- exp(pars[3])
      } else {
        sigma1sq <- exp(pars[3])
        sigma2sq <- exp(pars[4])
      }
    } 
  }
  # Create contrasts
  Z <- crossprod(diag(x = 1, nrow = n) - 
                   tcrossprod(myregF %*% 
                                chol2inv(chol(crossprod(myregF, myregF))),
                                         myregF), Y)
  myK <- cov_gen(x1 = X, t1 = meshT, phi1sq = phi1sq, phi2sq = phi2sq,
                 sigma1sq = sigma1sq, sigma2sq = sigma2sq, l=l,
                 covtype = covtype, H = H, iso = iso, nugget = nugget)
  myKi <- solve(myK)
  myKiF <- myKi %*% myregF
  myW <- crossprod(myregF, myKiF)
  myWi <- chol2inv(chol(myW))
  myval <- 1/2 * as.double(determinant(myK)$modulus) +
           1/2 * as.double(determinant(myW)$modulus) +
           (n-p)/2 * log(crossprod(Z, (myKi -myKiF %*%
                                      tcrossprod(myWi, myKiF)) %*% Z))
  return(c(myval))
}

